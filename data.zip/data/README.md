"concatenated_alignment_plastome_dataset.fasta"           #The concatenated alignment of Plastome dataset
"concatenated_alignment_plastome_dataset.partition"       #partition file of the concatenated plastome alignment; it contains three chloroplast genome region (LSC, SSC and IR).
The folder "HYBseq_datasets" inculdes the gene alignments of three Hyb-Seq datasets, i.e., HYB-89MO, HYB-98RT, HYB-114RT dataset.
The folder "transcriptome_datasets" inculdes the gene alignments of three transcriptome datasets, i.e., RNA-977MO, RNA-2821RT, RNA-4853RT dataset.

